# SAYAYIN — versión integrada 2026

## Abrir y publicar

- Abrir `index.html` en un navegador moderno.
- Para publicar, subir la carpeta `site` (su contenido) a Netlify Drop: https://app.netlify.com/drop .
- No se requieren compilación, instalación ni claves de API.

## Incluye

Portada mejorada, academia con plan imprimible, 8 herramientas complementarias con Mis Creaciones, ruta interactiva de 30 días, progreso con SAYA, asistencia guiada, registro de métricas, objetivo comercial, cálculo de campañas, comunidad local y catálogo demostrativo con carrito.

## Limitaciones importantes

- Los datos de este prototipo se guardan mediante localStorage: no se sincronizan entre personas, dispositivos ni navegadores.
- La comunidad no es multiusuario, no hay inicio de sesión real ni moderación remota.
- Los productos y precios de la tienda son demostrativos y las fotografías pueden ser ilustrativas; no se verificó que correspondan a un modelo exacto. No hay pagos ni envíos reales.
- Los videos incluidos en la base anterior no están verificados como tutoriales reales completos; requieren sustitución por material didáctico autorizado y revisado.
- SAYA funciona como guía programada, no como IA generativa conectada.
- La impresión del plan utiliza el diálogo del navegador, que permite guardar PDF.
- Para producción se necesita backend, autenticación, moderación, tratamiento de datos y validación de catálogo y videos.


Actualización Celulares: solo 15 modelos iPhone de Apple, ordenados por precio ilustrativo. No son ofertas reales ni precios verificados.

# SAYAYIN — Inicio reorganizado

Se rediseñó la página Inicio, conservando las secciones y funciones existentes.

- Portada azul/dorada con mascota original SAYA y botones de navegación.
- Presentación de beneficios y cuatro pasos.
- Accesos a ocho módulos.
- Diagnóstico y objetivos enlazados a las funciones del prototipo.
- Diseño adaptable a móvil.

Las fotografías y artículos de la tienda siguen siendo demostrativos, no un catálogo comercial verificado. No se incluyen testimonios ni métricas de usuarios inventados.

Para abrir, ejecutar index.html en un navegador moderno. Para Netlify, publicar la carpeta site.

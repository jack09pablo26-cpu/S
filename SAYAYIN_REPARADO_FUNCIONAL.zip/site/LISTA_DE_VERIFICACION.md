# Lista de verificación previa a la presentación

Marca cada punto después de comprobarlo en el navegador.

- [ ] `index.html` abre sin mostrar una página en blanco.
- [ ] Los botones del menú abren sus secciones.
- [ ] El diagnóstico muestra nivel y recomendaciones.
- [ ] Se puede abrir un módulo, revisar lecciones y comprobar el cuestionario.
- [ ] Se puede marcar un módulo completado y ver el progreso.
- [ ] La ruta personalizada se genera con un objetivo y presupuesto.
- [ ] Las herramientas de ideas, calendario, promociones y publicaciones responden.
- [ ] El botón para copiar el texto promocional funciona en el navegador elegido.
- [ ] El asistente muestra una respuesta al enviar una pregunta.
- [ ] El formulario de métricas registra datos ficticios y actualiza el panel.
- [ ] La comunidad permite publicar un aporte de prueba en ese navegador.
- [ ] El generador de QR acepta una URL completa que empiece con `https://` o `http://`.
- [ ] Se revisó el diseño en una pantalla estrecha o teléfono.
- [ ] Si se publicó en línea, se abrió el enlace desde una ventana privada o un dispositivo diferente.
- [ ] Si se comparte el enlace, el sitio no exige iniciar sesión en una cuenta del equipo.

**Importante:** los datos locales pueden quedar guardados en el navegador de la computadora usada para la demostración. Usa información ficticia y limpia los datos de prueba si compartes el equipo.

## Pruebas adicionales de la tienda online
- [ ] Abrir la sección Tienda desde el menú.
- [ ] Probar búsqueda y filtros por categoría.
- [ ] Añadir productos, aumentar/disminuir cantidades y retirar artículos.
- [ ] Verificar que el total se actualice correctamente.
- [ ] Registrar un pedido de demostración con datos ficticios.
- [ ] Confirmar que se explique que no hay cobro ni envío real.

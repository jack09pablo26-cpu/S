# SAYAYIN | Plataforma de asesoría en marketing para MYPES

Prototipo académico interactivo para orientar a micro y pequeñas empresas en la promoción de sus productos y servicios. Es una web estática: no requiere instalación ni compilación.

## Cómo abrirlo
1. Descomprime el archivo ZIP.
2. Abre `index.html` con Chrome, Edge o Firefox.
3. Para una demostración más completa, usa una ventana normal del navegador para que se guarde el progreso localmente.

## Funciones incluidas
- Diagnóstico inicial de marketing y recomendaciones.
- 10 módulos formativos, con 3 lecciones cada uno y mini cuestionario.
- Ruta de crecimiento personalizada por objetivo y presupuesto.
- Generador de ideas, calendario de publicaciones y promociones.
- Redacción de textos promocionales para redes sociales.
- Asistente demostrativo con recomendaciones predefinidas.
- Retos, puntos, niveles e insignias.
- Registro manual de ventas, gastos de marketing, consultas y clientes nuevos.
- Espacio de comunidad demostrativo.
- Generador de QR para una URL pública.
- Tienda online demostrativa con catálogo de 9 productos relacionados con marketing, búsqueda, filtros por categoría, carrito, cantidades, cálculo del total y registro de pedidos de prueba.
- Diseño adaptable a computadora, tableta y celular.

## Publicar en Netlify
1. Entra en https://app.netlify.com/drop e inicia sesión.
2. Descomprime este ZIP en tu computadora.
3. Arrastra la carpeta `site` (o su contenido) a Netlify Drop. Asegúrate de que `index.html`, `styles.css` y `app.js` queden en la raíz publicada, no dentro de una subcarpeta adicional.
4. Espera a que finalice la publicación y abre la URL `https://...netlify.app` que Netlify muestre.
5. Comprueba el enlace desde una ventana privada o un teléfono. Si quieres que cualquiera pueda acceder, revisa que el sitio no exija inicio de sesión del equipo.

## Limitaciones que deben explicarse en la presentación
- Es un prototipo frontend académico, no un servicio de producción.
- El asistente ofrece respuestas por reglas; no está conectado a una IA externa.
- El progreso, perfil, métricas y aportes se guardan en el navegador mediante `localStorage`; no se sincronizan entre personas o dispositivos.
- La comunidad es demostrativa y no es un espacio público compartido ni moderado.
- El QR usa un servicio externo y requiere una URL pública válida.
- La tienda online es demostrativa: los precios son referenciales, los pedidos quedan en el navegador y no se cobran ni se envían productos. Antes de vender de verdad, hay que confirmar proveedores, inventario, costos, entrega, políticas de cambios/devoluciones y conectar un medio de pago seguro.
- Las ventas y métricas se registran manualmente; no se conectan a redes sociales ni sistemas de pago.
- No introduzcas datos personales sensibles ni información financiera real de clientes.

## Archivos
- `index.html`: estructura y pantallas.
- `styles.css`: estilos y adaptación a pantallas.
- `app.js`: interacciones y datos locales.
- `GUIA_PRESENTACION.md`: guion breve para exponer el prototipo.
- `LISTA_DE_VERIFICACION.md`: pasos de prueba antes de presentar.


Actualización visual: portada de inicio rediseñada con colores vivos, fotografía ilustrativa, tarjetas de acceso y llamadas a la acción. Las demás funciones de la plataforma y tienda se mantienen.


## Versión 5 — Cambios 1 a 5
- Portada colorida conservada.
- Tienda tecnológica: 10 categorías, 44 productos demostrativos, orden por precio, carrito.
- Academia: 30 lecciones con clips audiovisuales locales de introducción y enlaces de búsqueda de tutoriales en español. **Los clips son introducciones de 3 segundos, no tutoriales completos**; los enlaces llevan a resultados de YouTube, no videos seleccionados.
- Fondo azul y dorado de referencia en todas las secciones.
- Mascota SAYA basada en la imagen aprobada: botón flotante y navegación guiada, no IA conversacional. La imagen es un recorte de la lámina conceptual, no un archivo de diseño técnico para botarga.
- Pagos y pedidos: simulación local. Precios ilustrativos.


## Fotografías reales en la tienda (actualización)
La tienda ahora incluye fotografías **reales ilustrativas** de productos tecnológicos obtenidas mediante enlaces a Wikimedia Commons, con atribución en `CREDITOS_FOTOGRAFIAS.md`. Algunas fotos se reutilizan en variantes de una misma categoría y **no identifican el modelo exacto que se vende**. Los artículos digitales conservan ilustraciones por no ser productos físicos. Las fotografías necesitan conexión a Internet; si no cargan, se muestran los iconos anteriores. Para una tienda comercial real, sustituye cada foto por la imagen verificada del SKU exacto de tu proveedor. Los precios siguen siendo referenciales y la compra es demostrativa.


## Entrega final de revisión (cambios 1–7)
- Cambio 7: logotipo oficial proporcionado por el usuario en encabezado, tienda, pie de página y favicon.
- Los cambios 1–5 y fotografías de referencia de la tienda se conservan de la versión anterior.
- Las fotografías de productos son referenciales, no necesariamente corresponden al modelo específico.
- Los clips breves no reemplazan tutoriales reales completos; la integración de tutoriales verificados está pendiente.
- Tienda, comunidad y asistente son demostraciones, no servicios de comercio/IA reales.
- La imagen de mascota es un concepto gráfico para el prototipo, no planos técnicos de botarga.
